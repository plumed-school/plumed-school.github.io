terminate called after throwing an instance of 'PLMD::Plumed::Exception'
  what():  
Action "PYCVINTERFACE" is not known.
[runnervm76f27:04512] *** Process received signal ***
[runnervm76f27:04512] Signal: Aborted (6)
[runnervm76f27:04512] Signal code:  (-6)
[runnervm76f27:04512] [ 0] /lib/x86_64-linux-gnu/libc.so.6(+0x45330)[0x7f1f90c45330]
[runnervm76f27:04512] [ 1] /lib/x86_64-linux-gnu/libc.so.6(pthread_kill+0x11c)[0x7f1f90c9ec0c]
[runnervm76f27:04512] [ 2] /lib/x86_64-linux-gnu/libc.so.6(gsignal+0x1e)[0x7f1f90c4527e]
[runnervm76f27:04512] [ 3] /lib/x86_64-linux-gnu/libc.so.6(abort+0xdf)[0x7f1f90c288ff]
[runnervm76f27:04512] [ 4] /lib/x86_64-linux-gnu/libstdc++.so.6(+0xa5ff5)[0x7f1f910a5ff5]
[runnervm76f27:04512] [ 5] /lib/x86_64-linux-gnu/libstdc++.so.6(+0xbb0da)[0x7f1f910bb0da]
[runnervm76f27:04512] [ 6] /lib/x86_64-linux-gnu/libstdc++.so.6(_ZSt10unexpectedv+0x0)[0x7f1f910a5a55]
[runnervm76f27:04512] [ 7] /lib/x86_64-linux-gnu/libstdc++.so.6(+0xa5a6f)[0x7f1f910a5a6f]
[runnervm76f27:04512] [ 8] plumed_master(+0x146dd)[0x55722d8976dd]
[runnervm76f27:04512] [ 9] /lib/x86_64-linux-gnu/libc.so.6(+0x2a1ca)[0x7f1f90c2a1ca]
[runnervm76f27:04512] [10] /lib/x86_64-linux-gnu/libc.so.6(__libc_start_main+0x8b)[0x7f1f90c2a28b]
[runnervm76f27:04512] [11] plumed_master(+0x15365)[0x55722d898365]
[runnervm76f27:04512] *** End of error message ***
