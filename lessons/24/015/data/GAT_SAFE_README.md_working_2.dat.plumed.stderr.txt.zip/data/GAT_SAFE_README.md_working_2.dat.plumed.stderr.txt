terminate called after throwing an instance of 'PLMD::Plumed::Exception'
  what():  
Action "PYFUNCTION" is not known.
[runnervm76f27:04540] *** Process received signal ***
[runnervm76f27:04540] Signal: Aborted (6)
[runnervm76f27:04540] Signal code:  (-6)
[runnervm76f27:04540] [ 0] /lib/x86_64-linux-gnu/libc.so.6(+0x45330)[0x7f62f5e45330]
[runnervm76f27:04540] [ 1] /lib/x86_64-linux-gnu/libc.so.6(pthread_kill+0x11c)[0x7f62f5e9ec0c]
[runnervm76f27:04540] [ 2] /lib/x86_64-linux-gnu/libc.so.6(gsignal+0x1e)[0x7f62f5e4527e]
[runnervm76f27:04540] [ 3] /lib/x86_64-linux-gnu/libc.so.6(abort+0xdf)[0x7f62f5e288ff]
[runnervm76f27:04540] [ 4] /lib/x86_64-linux-gnu/libstdc++.so.6(+0xa5ff5)[0x7f62f62a5ff5]
[runnervm76f27:04540] [ 5] /lib/x86_64-linux-gnu/libstdc++.so.6(+0xbb0da)[0x7f62f62bb0da]
[runnervm76f27:04540] [ 6] /lib/x86_64-linux-gnu/libstdc++.so.6(_ZSt10unexpectedv+0x0)[0x7f62f62a5a55]
[runnervm76f27:04540] [ 7] /lib/x86_64-linux-gnu/libstdc++.so.6(+0xa5a6f)[0x7f62f62a5a6f]
[runnervm76f27:04540] [ 8] plumed(+0x146dd)[0x556f26ddc6dd]
[runnervm76f27:04540] [ 9] /lib/x86_64-linux-gnu/libc.so.6(+0x2a1ca)[0x7f62f5e2a1ca]
[runnervm76f27:04540] [10] /lib/x86_64-linux-gnu/libc.so.6(__libc_start_main+0x8b)[0x7f62f5e2a28b]
[runnervm76f27:04540] [11] plumed(+0x15365)[0x556f26ddd365]
[runnervm76f27:04540] *** End of error message ***
