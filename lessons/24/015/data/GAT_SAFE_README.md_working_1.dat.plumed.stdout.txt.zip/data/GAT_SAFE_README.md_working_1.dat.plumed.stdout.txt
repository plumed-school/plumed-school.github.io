PLUMED: PLUMED is starting
PLUMED: Version: 2.10.1 (git: 6d75105c2) compiled on Aug 18 2026 at 14:28:05
PLUMED: Please cite these papers when using PLUMED [1][2]
PLUMED: For further information see the PLUMED web page at http://www.plumed.org
PLUMED: Root: /home/runner/opt/lib/plumed
PLUMED: LibraryPath: /home/runner/opt/lib/libplumedKernel.so
PLUMED: For installed feature, see /home/runner/opt/lib/plumed/src/config/config.txt
PLUMED: Molecular dynamics engine: driver
PLUMED: Precision of reals: 8
PLUMED: Running over 1 node
PLUMED: Number of threads: 1
PLUMED: Cache line size: 512
PLUMED: Number of atoms: 100000
PLUMED: File suffix: 
PLUMED: FILE: GAT_SAFE_README.md_working_1.dat
PLUMED: 
PLUMED: ################################################################################
PLUMED: 
PLUMED: Action "PYCVINTERFACE" is not known.
PLUMED: ################################################################################
