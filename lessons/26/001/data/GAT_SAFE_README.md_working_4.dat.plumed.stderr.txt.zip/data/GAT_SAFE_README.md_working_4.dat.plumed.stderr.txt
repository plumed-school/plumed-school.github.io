terminate called after throwing an instance of 'PLMD::Plumed::ExceptionError'
  what():  
(core/GenericMolInfo.cpp:93) PLMD::GenericMolInfo::GenericMolInfo(const PLMD::ActionOptions&)
missing input file input.ala2.pdb
[runnervm76f27:04341] *** Process received signal ***
[runnervm76f27:04341] Signal: Aborted (6)
[runnervm76f27:04341] Signal code:  (-6)
[runnervm76f27:04341] [ 0] /lib/x86_64-linux-gnu/libc.so.6(+0x45330)[0x7f3d10645330]
[runnervm76f27:04341] [ 1] /lib/x86_64-linux-gnu/libc.so.6(pthread_kill+0x11c)[0x7f3d1069ec0c]
[runnervm76f27:04341] [ 2] /lib/x86_64-linux-gnu/libc.so.6(gsignal+0x1e)[0x7f3d1064527e]
[runnervm76f27:04341] [ 3] /lib/x86_64-linux-gnu/libc.so.6(abort+0xdf)[0x7f3d106288ff]
[runnervm76f27:04341] [ 4] /lib/x86_64-linux-gnu/libstdc++.so.6(+0xa5ff5)[0x7f3d10aa5ff5]
[runnervm76f27:04341] [ 5] /lib/x86_64-linux-gnu/libstdc++.so.6(+0xbb0da)[0x7f3d10abb0da]
[runnervm76f27:04341] [ 6] /lib/x86_64-linux-gnu/libstdc++.so.6(_ZSt10unexpectedv+0x0)[0x7f3d10aa5a55]
[runnervm76f27:04341] [ 7] /lib/x86_64-linux-gnu/libstdc++.so.6(+0xa5a6f)[0x7f3d10aa5a6f]
[runnervm76f27:04341] [ 8] plumed(+0x146dd)[0x564bde4e06dd]
[runnervm76f27:04341] [ 9] /lib/x86_64-linux-gnu/libc.so.6(+0x2a1ca)[0x7f3d1062a1ca]
[runnervm76f27:04341] [10] /lib/x86_64-linux-gnu/libc.so.6(__libc_start_main+0x8b)[0x7f3d1062a28b]
[runnervm76f27:04341] [11] plumed(+0x15365)[0x564bde4e1365]
[runnervm76f27:04341] *** End of error message ***
